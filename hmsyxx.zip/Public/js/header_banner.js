$(document).ready(function(e){
	  var opt	=	{
		"speed"	:	"slow"		,
		"by"	:	"click"		,
		"auto"	:	true		,
		"sec"	:	4000	 	
	  };
      $("#header_banner").IMGDEMO(opt);    
});